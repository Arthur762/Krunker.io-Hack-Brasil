# Bem-vindo ao Krunker.io Hack's Brasil!
Este � um Hack Para Krunker.io carregado como uma extens�o do Chrome.

##: muscle: recursos

* Aimbot
* Apelidos vis�veis atrav�s das paredes
* Sem recuo
* Contador FPS

###: information_source: instru��es

- Pressione a tecla Z para ativar / desativar o Hack.
- Se voc� precisar desabilitar temporariamente a mira autom�tica, apenas segure a tecla Shift esquerda.

##: hammer: Instala��o

1. Baixe [este reposit�rio como um arquivo ZIP] (https://github.com/Arthur762/Krunker.io-Hack-Brasil/archive/master.zip).
2. Extraia o arquivo ZIP que voc� acabou de baixar.
3. V� para "chrome: // extensions" no seu navegador. * Certifique-se de ter ativado o modo de desenvolvedor. *
4. Clique em "Carregar Sem Compacta��o" e selecione a subpasta chamada "ChromeExtension" que est� Extraida (chamado `Krunker.io Hack's Brasil)
5. Abra o [Krunker.io] (http://krunker.io).
6. Divirta-se!

##: warning: Aten��o!
Todas as a��es que voc� toma por sua conta e risco. O autor n�o � respons�vel pelas consequ�ncias de suas a��es.


